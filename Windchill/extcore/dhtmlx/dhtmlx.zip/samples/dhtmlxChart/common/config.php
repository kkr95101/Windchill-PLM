<?php
/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
This version of Software is free for using in non-commercial applications.
For commercial use please contact sales@dhtmlx.com to obtain license
*/

    $mysql_host = "localhost";
    $mysql_user = "root";
    $mysql_pasw = "";
    $mysql_db   = "sampledb";

?>
